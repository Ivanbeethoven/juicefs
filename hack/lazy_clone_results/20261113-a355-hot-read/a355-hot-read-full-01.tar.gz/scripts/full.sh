#!/usr/bin/env bash
set -u
taskroot=$(cd "$(dirname "$0")/.." && pwd)
printf '%s\n' "$$" > "$taskroot/full.pid"
python3 "$taskroot/scripts/lazy_clone_read_bench.py" \
  --binary "$taskroot/bin/juicefs" --out "$taskroot/full-01" \
  --source-commit 7aaafbe3c40b1b377accffd00755a7259f4f44e9 --pairs 3
code=$?
printf '%s\n' "$code" > "$taskroot/full.exit"
exit "$code"
