#!/usr/bin/env bash
set -u
taskroot=$(cd "$(dirname "$0")/.." && pwd)
attempt=${1:?provide a new attempt suffix}
printf '%s\n' "$$" > "$taskroot/quick-$attempt.pid"
python3 "$taskroot/scripts/lazy_clone_read_bench.py" \
  --binary "$taskroot/bin/juicefs" --out "$taskroot/quick-$attempt" \
  --source-commit 7aaafbe3c40b1b377accffd00755a7259f4f44e9 --quick --pairs 1
code=$?
printf '%s\n' "$code" > "$taskroot/quick-$attempt.exit"
exit "$code"
