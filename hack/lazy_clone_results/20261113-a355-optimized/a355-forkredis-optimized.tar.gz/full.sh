#!/usr/bin/env bash
root=/srv/juicefs-forkredis-opt-20261113
python3 "$root/scripts/lazy_clone_read_bench.py" --binary "$root/bin/juicefs-before" --compare-binary "$root/bin/juicefs-after" --source-commit 7aaafbe3c40b1b377accffd00755a7259f4f44e9 --compare-commit c8a4035a17d79ebdffe2876f85b1ce66c6ee5430 --out "$root/full-01" --pairs 3
code=$?
printf '%s\n' "$code" > "$root/full.exit"
exit "$code"
