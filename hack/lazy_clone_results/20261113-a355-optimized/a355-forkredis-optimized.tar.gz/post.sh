#!/usr/bin/env bash
set -euo pipefail
root=/srv/juicefs-forkredis-opt-20261113
while [ ! -f "$root/full.exit" ]; do sleep 5; done
test "$(cat "$root/full.exit")" = 0
python3 "$root/scripts/lazy_clone_read_report.py" "$root/full-01" > "$root/full-report.log"
python3 "$root/scripts/lazy_clone_read_bench.py" --binary "$root/bin/juicefs-before" --compare-binary "$root/bin/juicefs-after" --source-commit 7aaafbe3c40b1b377accffd00755a7259f4f44e9 --compare-commit c8a4035a17d79ebdffe2876f85b1ce66c6ee5430 --compare-cache-bytes 0 --profile default --fixture small128 --out "$root/batch-only-01" --pairs 3
python3 "$root/scripts/lazy_clone_read_report.py" "$root/batch-only-01" > "$root/batch-report.log"
python3 "$root/scripts/postflight.py"
printf '0\n' > "$root/post.exit"
