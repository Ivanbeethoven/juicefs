#!/usr/bin/env python3
"""Run the existing FUSE write/isolation check on an owned Redis, then stop it."""
import hashlib
import json
from pathlib import Path
import socket
import subprocess
import time

root = Path(__file__).resolve().parent.parent
with socket.socket() as s:
    s.bind(('127.0.0.1', 0))
    port = s.getsockname()[1]
out = root/'fuse-validation'
out.mkdir(exist_ok=False)
argv = ['redis-server', '--bind', '127.0.0.1', '--port', str(port), '--protected-mode', 'yes',
        '--save', '', '--appendonly', 'no', '--maxmemory', '256mb', '--maxmemory-policy', 'noeviction',
        '--dir', str(out), '--logfile', str(out/'redis.log')]
process = subprocess.Popen(argv, stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
result = {'passed': False, 'redis_argv': argv, 'redis_stopped': False}
try:
    for i in range(100):
        try:
            with socket.create_connection(('127.0.0.1', port), timeout=.1):
                break
        except OSError:
            assert process.poll() is None
            time.sleep(.05)
    else:
        raise RuntimeError('Redis readiness timeout')
    argv = ['python3', str(root/'scripts/lazy_clone_smoke.py'), '--binary', str(root/'bin/juicefs-after'),
            '--redis', f'127.0.0.1:{port}', '--out', str(out/'smoke')]
    result['smoke_argv'] = argv
    with (out/'smoke.log').open('wb') as log:
        subprocess.run(argv, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=180)
    smoke = json.loads((out/'smoke/result.json').read_text())
    assert smoke['passed'] and smoke['mounts_closed']
    result['smoke_sha256'] = hashlib.sha256((out/'smoke/result.json').read_bytes()).hexdigest()
    result['passed'] = True
finally:
    process.terminate()
    process.wait(timeout=15)
    result['redis_stopped'] = process.poll() is not None
    (out/'result.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
