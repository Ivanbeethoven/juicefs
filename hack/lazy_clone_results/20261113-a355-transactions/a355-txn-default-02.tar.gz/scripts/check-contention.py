import json
import os
from pathlib import Path
import time

root = Path('/srv/juicefs-txn-opt-20261113')


def snapshot():
    sample = {'monotonic': time.monotonic(), 'unix': time.time()}
    sample['cpu'] = {fields[0]: list(map(int, fields[1:9])) for line in Path('/proc/stat').read_text().splitlines()
                     if (fields := line.split()) and fields[0].startswith('cpu')}
    sample['memory_kib'] = {key: int(value.split()[0]) for key, value in
                            (line.split(':', 1) for line in Path('/proc/meminfo').read_text().splitlines())}
    sample['pressure'] = {name: Path('/proc/pressure', name).read_text() for name in ('cpu', 'io', 'memory')}
    sample['disks'] = {}
    for line in Path('/proc/diskstats').read_text().splitlines():
        fields = line.split()
        name = fields[2]
        if name.startswith(('loop', 'ram', 'dm-')) or Path('/sys/class/block', name, 'partition').exists():
            continue
        sample['disks'][name] = list(map(int, fields[3:]))
    sample['processes'] = {}
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            command = (proc / 'cmdline').read_bytes().replace(b'\0', b' ').decode(errors='replace')
            if not (('/srv/ax-overlay-' in command and ('run_detail.py' in command or 'brewfs mount' in command
                                                     or 'packed_snapshot_fixture' in command))
                    or command.startswith('redis-server')):
                continue
            stat = (proc / 'stat').read_text().split(') ', 1)[1].split()
            status = dict(line.split(':', 1) for line in (proc / 'status').read_text().splitlines() if ':' in line)
            io = dict((key, int(value)) for key, value in
                      (line.split(':', 1) for line in (proc / 'io').read_text().splitlines()))
            sample['processes'][proc.name] = {'command': command, 'cpu_ticks': int(stat[11])+int(stat[12]),
                                            'rss_kib': int(status.get('VmRSS', '0').split()[0]),
                                            'cpus_allowed': status['Cpus_allowed_list'].strip(), 'io': io}
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            pass
    return sample


samples = [snapshot()]
for _ in range(5):
    time.sleep(3)
    samples.append(snapshot())
intervals = []
for before, after in zip(samples, samples[1:]):
    dt = after['monotonic']-before['monotonic']
    row = {'seconds': dt, 'cpu_busy_percent': {}, 'disks': {}, 'processes': {}}
    for name in ['cpu'] + [f'cpu{i}' for i in range(8, 14)]:
        delta = [a-b for a, b in zip(after['cpu'][name], before['cpu'][name])]
        row['cpu_busy_percent'][name] = 100*(1-(delta[3]+delta[4])/sum(delta)) if sum(delta) else 0
    for name, a in after['disks'].items():
        d = [x-y for x, y in zip(a, before['disks'][name])]
        ios = d[0]+d[4]
        row['disks'][name] = {'iops': ios/dt, 'busy_percent': d[9]/(10*dt),
                              'read_mib_s': d[2]*512/(dt*2**20), 'write_mib_s': d[6]*512/(dt*2**20),
                              'await_ms': (d[3]+d[7])/ios if ios else 0,
                              'average_inflight': d[10]/(1000*dt)}
    for pid, a in after['processes'].items():
        if pid not in before['processes']:
            continue
        b = before['processes'][pid]
        row['processes'][pid] = {'cpu_percent_one_core': 100*(a['cpu_ticks']-b['cpu_ticks'])/os.sysconf('SC_CLK_TCK')/dt,
                                  'rss_mib': a['rss_kib']/1024,
                                  'read_mib_s': (a['io']['read_bytes']-b['io']['read_bytes'])/(dt*2**20),
                                  'write_mib_s': (a['io']['write_bytes']-b['io']['write_bytes'])/(dt*2**20),
                                  'command': a['command']}
    intervals.append(row)
result = {'samples': samples, 'intervals': intervals}
path = root / 'contention-01.json'
assert not path.exists()
path.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({'samples': len(samples), 'memory_available_gib': samples[-1]['memory_kib']['MemAvailable']/2**20,
                  'memory_total_gib': samples[-1]['memory_kib']['MemTotal']/2**20,
                  'intervals': intervals, 'pressure': samples[-1]['pressure']}, indent=2))
