import hashlib
import json
from pathlib import Path
import tarfile

root=Path('/srv/juicefs-txn-opt-20261113')
assert (root/'default-02.exit').read_text().strip() == '0'
run=json.loads((root/'default-02/run.json').read_text())
assert run['passed'] and run['mounts_closed'] and run['redis_stopped']
assert len(run['cells']) == 54 and all(c['valid'] for c in run['cells'])
files=set(p for p in (root/'default-02').glob('*') if p.is_file())
files.update(p for p in (root/'default-02/cells').rglob('*') if p.is_file())
files.update((root/'default-02/redis').glob('*.log'))
files.update(root/name for name in ['default-02.exit','default-02.log','default-02-report.log','contention-01.json',
                                   'scripts/run-default-02.sh','scripts/check-contention.py','scripts/archive-default-02.py'])
manifest=root/'DEFAULT02-SHA256SUMS.txt'
manifest.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(root))+'\n' for p in sorted(files)))
files.add(manifest)
archive=root/'a355-txn-default-02.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz',compresslevel=6) as stream:
    for path in sorted(files):
        stream.add(path,arcname=str(path.relative_to(root)),recursive=False)
result={'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'files':len(files),'cells':54}
(root/'archive-default-02.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
