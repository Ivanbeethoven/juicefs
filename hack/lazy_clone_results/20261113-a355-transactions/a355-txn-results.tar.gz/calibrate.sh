#!/usr/bin/env bash
root=/srv/juicefs-txn-opt-20261113
python3 "$root/scripts/lazy_clone_read_bench.py" --binary "$root/bin/juicefs-uninstrumented" --compare-binary "$root/bin/juicefs-before" --source-commit c8a4035a17d79ebdffe2876f85b1ce66c6ee5430 --compare-commit 943e569cfb838f93ae64cc2df4b4d86bd78400a7 --out "$root/calibration-01" --profile default --fixture small128 --pairs 3
printf '%s\n' "$?" > "$root/calibration.exit"
