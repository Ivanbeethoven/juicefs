import hashlib
import json
from pathlib import Path
import platform
import tarfile
import time

root = Path('/srv/juicefs-txn-opt-20261113')
assert (root / 'batch.exit').read_text().strip() == '0'
checks = {}
for name in ['calibration-02', 'quick-01', 'full-01']:
    run = json.loads((root / name / 'run.json').read_text())
    assert run['passed'] and run['mounts_closed'] and run['redis_stopped']
    assert all(c['valid'] and c['observed']['object_gets'] == c['observed']['object_get_bytes'] == 0
               for c in run['cells'])
    checks[name] = len(run['cells'])
fuse = json.loads((root / 'fuse-validation/result.json').read_text())
assert fuse['passed'] and fuse['redis_stopped']
assert str(root) not in Path('/proc/mounts').read_text()
active = []
other_benchmarks = []
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():
        continue
    try:
        argv = (proc / 'cmdline').read_bytes().split(b'\0')
        if argv and argv[0].decode(errors='replace').startswith(str(root / 'bin') + '/'):
            active.append(proc.name)
        command = b' '.join(argv).decode(errors='replace')
        if ('run_detail.py' in command or 'brewfs mount' in command) and '/srv/ax-overlay-' in command:
            other_benchmarks.append({'pid': proc.name, 'command': command,
                                     'status': (proc / 'status').read_text(),
                                     'stat': (proc / 'stat').read_text()})
    except (FileNotFoundError, ProcessLookupError, PermissionError):
        pass
assert not active, active
archive = root / 'a355-txn-results.tar.gz'
assert not archive.exists()
files = set()
for name in ['calibration-01', 'calibration-02', 'quick-01', 'full-01']:
    directory = root / name
    files.update(p for p in directory.glob('*') if p.is_file())
    files.update(p for p in (directory / 'cells').rglob('*') if p.is_file())
    files.update((directory / 'redis').glob('*.log'))
files.update(p for p in (root / 'scripts').glob('*') if p.is_file())
files.update(p for p in (root / 'fuse-validation').glob('*') if p.is_file())
files.update(p for p in (root / 'fuse-validation/smoke').glob('*') if p.is_file())
for name in ['batch.log', 'batch.exit', 'calibrate.sh', 'calibration.log', 'calibration.exit',
             'postflight.log', 'full-report.log', 'quick-report.log', 'calibration-report.log']:
    files.add(root / name)
collection = {'host': platform.uname()._asdict(), 'unix_seconds': time.time(), 'checks': checks,
              'fuse_passed': True, 'task_mounts_remaining': [], 'task_binary_processes_remaining': active,
              'other_benchmarks_at_collection': other_benchmarks,
              'contention_note': 'Another BrewFS benchmark was observed during this run, with allowed CPUs 0-127; this run is not an exclusive-host performance measurement.',
              'excluded': 'binaries, generated object data, Redis persistence files; inputs reproducible from fixed seeds'}
(root / 'collection.json').write_text(json.dumps(collection, indent=2) + '\n')
files.add(root / 'collection.json')
manifest = ''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + str(p.relative_to(root)) + '\n'
                   for p in sorted(files))
(root / 'RAW-SHA256SUMS.txt').write_text(manifest)
files.add(root / 'RAW-SHA256SUMS.txt')
with tarfile.open(archive, 'w:gz', compresslevel=6) as stream:
    for path in sorted(files):
        stream.add(path, arcname=str(path.relative_to(root)), recursive=False)
result = {'archive': str(archive), 'bytes': archive.stat().st_size,
          'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'files': len(files), 'checks': checks}
(root / 'archive.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
